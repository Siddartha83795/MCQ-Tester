
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { DataProvider } from "@/contexts/DataContext";
import { QuizProvider } from "@/contexts/QuizContext";

// Pages
import Index from "./pages/Index";
import Login from "./pages/Login";
import RegisterStaff from "./pages/RegisterStaff";
import Dashboard from "./pages/Dashboard";
import RegisterStudent from "./pages/RegisterStudent";
import ManageQuestions from "./pages/ManageQuestions";
import ViewResults from "./pages/ViewResults";
import TakeQuiz from "./pages/TakeQuiz";
import StudentResults from "./pages/StudentResults";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <DataProvider>
        <QuizProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <div className="min-h-screen bg-gray-50">
                <Routes>
                  <Route path="/" element={<Index />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/register-staff" element={<RegisterStaff />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/register-student" element={<RegisterStudent />} />
                  <Route path="/manage-questions" element={<ManageQuestions />} />
                  <Route path="/view-results" element={<ViewResults />} />
                  <Route path="/quiz/:subject" element={<TakeQuiz />} />
                  <Route path="/student-results" element={<StudentResults />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </div>
            </BrowserRouter>
          </TooltipProvider>
        </QuizProvider>
      </DataProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
