
import { Staff, Student, Question } from "@/types";

// Add initial staff user if none exists
export function seedData() {
  // Initialize localStorage with default data if it doesn't exist
  if (!localStorage.getItem("users")) {
    const defaultStaff: Staff = {
      id: "staff-1",
      username: "admin",
      password: "admin123",
      name: "Administrator",
      role: "staff"
    };
    
    const defaultStudent: Student = {
      id: "student-1",
      username: "student1",
      password: "student123",
      name: "John Doe",
      usn: "ENG23CT0001",
      section: "CST",
      role: "student"
    };
    
    localStorage.setItem("users", JSON.stringify([defaultStaff, defaultStudent]));
  }
  
  // Add sample questions if none exist
  if (!localStorage.getItem("questions")) {
    const sampleQuestions: Question[] = [
      {
        id: "q1",
        text: "What is 2 + 2?",
        subject: "Mathematics",
        options: [
          { id: "q1-opt1", text: "3" },
          { id: "q1-opt2", text: "4" },
          { id: "q1-opt3", text: "5" },
          { id: "q1-opt4", text: "6" }
        ],
        correctOptionId: "q1-opt2"
      },
      {
        id: "q2",
        text: "Which planet is known as the Red Planet?",
        subject: "Science",
        options: [
          { id: "q2-opt1", text: "Venus" },
          { id: "q2-opt2", text: "Jupiter" },
          { id: "q2-opt3", text: "Mars" },
          { id: "q2-opt4", text: "Mercury" }
        ],
        correctOptionId: "q2-opt3"
      },
      {
        id: "q3",
        text: "What is the capital of France?",
        subject: "Geography",
        options: [
          { id: "q3-opt1", text: "London" },
          { id: "q3-opt2", text: "Berlin" },
          { id: "q3-opt3", text: "Madrid" },
          { id: "q3-opt4", text: "Paris" }
        ],
        correctOptionId: "q3-opt4"
      }
    ];
    
    localStorage.setItem("questions", JSON.stringify(sampleQuestions));
  }
  
  // Initialize empty quiz attempts if not exists
  if (!localStorage.getItem("quizAttempts")) {
    localStorage.setItem("quizAttempts", JSON.stringify([]));
  }
}
