
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { QuizContainer } from "@/components/Quiz";
import { Student } from "@/types";

export default function TakeQuiz() {
  const { isAuthenticated, isStudent, currentUser } = useAuth();
  const navigate = useNavigate();
  const { subject } = useParams<{ subject: string }>();
  const [isQuizStarted, setIsQuizStarted] = useState(false);
  
  useEffect(() => {
    if (!isAuthenticated || !isStudent) {
      navigate("/login");
    }
    
    if (!subject) {
      navigate("/dashboard");
    }
  }, [isAuthenticated, isStudent, navigate, subject]);

  if (!currentUser || !subject) {
    return null;
  }

  const student = currentUser as Student;
  
  const handleQuizComplete = () => {
    navigate("/dashboard");
  };

  const handleStartQuiz = () => {
    setIsQuizStarted(true);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-4xl mx-auto">
        {!isQuizStarted && (
          <>
            <div className="mb-4">
              <Button 
                variant="ghost" 
                onClick={() => navigate("/dashboard")}
                className="flex items-center gap-2 text-gray-600"
              >
                <ArrowLeft className="h-4 w-4" /> Back to Dashboard
              </Button>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <h1 className="text-2xl font-bold mb-4">{subject} Quiz</h1>
              <p className="mb-6 text-gray-600">
                You are about to start the {subject} quiz. Once you begin, you must complete the quiz.
                Your answers will be saved and your final score will be displayed at the end.
              </p>
              <Button 
                onClick={handleStartQuiz}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                Start Quiz
              </Button>
            </div>
          </>
        )}
        
        {isQuizStarted && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <QuizContainer 
              subject={subject} 
              studentId={student.id} 
              onQuizComplete={handleQuizComplete} 
            />
          </div>
        )}
      </div>
    </div>
  );
}
