
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { DashboardHeader } from "@/components/Dashboard";
import { QuestionManagementForm, QuestionsList } from "@/components/QuestionManagement";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ManageQuestions() {
  const { isAuthenticated, isStaff, currentUser } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    if (!isAuthenticated || !isStaff) {
      navigate("/login");
    }
  }, [isAuthenticated, isStaff, navigate]);

  if (!currentUser) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate("/dashboard")}
            className="flex items-center gap-2 text-gray-600"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Dashboard
          </Button>
        </div>
        
        <DashboardHeader 
          title="Manage Questions" 
          userName={currentUser.username} 
        />
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <QuestionManagementForm />
          <QuestionsList />
        </div>
      </div>
    </div>
  );
}
