
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { DashboardHeader, DashboardCard, ResultCard } from "@/components/Dashboard";
import { Student } from "@/types";
import { UserPlus, BookOpen, LineChart } from "lucide-react";
import { useData } from "@/contexts/DataContext";

export default function Dashboard() {
  const { isAuthenticated, isStaff, isStudent, currentUser } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  if (!currentUser) {
    return null;
  }

  if (isStaff) {
    return (
      <div className="min-h-screen bg-gray-100 p-6">
        <div className="max-w-6xl mx-auto">
          <DashboardHeader 
            title="Staff Dashboard" 
            userName={currentUser.username} 
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <DashboardCard
              title="Register Student"
              description="Add new students to the system"
              icon={<UserPlus className="h-6 w-6" />}
              to="/register-student"
            />
            
            <DashboardCard
              title="Manage Questions"
              description="Add or edit quiz questions"
              icon={<BookOpen className="h-6 w-6" />}
              to="/manage-questions"
            />
            
            <DashboardCard
              title="View Results"
              description="Review student performance and export data"
              icon={<LineChart className="h-6 w-6" />}
              to="/view-results"
            />
          </div>
        </div>
      </div>
    );
  }

  if (isStudent) {
    const student = currentUser as Student;
    const { getQuizAttempts, getSubjects } = useData();
    const studentResults = getQuizAttempts(student.id);
    const subjects = getSubjects();
    
    return (
      <div className="min-h-screen bg-gray-100 p-6">
        <div className="max-w-6xl mx-auto">
          <DashboardHeader 
            title="Student Dashboard" 
            userName={student.name} 
            additionalInfo={`USN: ${student.usn} | Section: ${student.section}`}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <BookOpen className="h-5 w-5 mr-2 text-indigo-600" />
                Available Tests
              </h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {subjects.map((subject) => (
                  <DashboardCard
                    key={subject}
                    title={subject}
                    description={`Test your knowledge on ${subject} topics`}
                    icon={<BookOpen className="h-5 w-5" />}
                    to={`/quiz/${subject.toLowerCase()}`}
                  />
                ))}
                
                {subjects.length === 0 && (
                  <p className="text-gray-500 col-span-2">No quizzes available yet.</p>
                )}
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <LineChart className="h-5 w-5 mr-2 text-indigo-600" />
                Your Results
              </h2>
              
              <div className="space-y-3">
                {studentResults.length > 0 ? (
                  studentResults.map((result) => (
                    <ResultCard
                      key={result.id}
                      subject={result.subject}
                      score={result.score}
                      totalQuestions={result.totalQuestions}
                    />
                  ))
                ) : (
                  <p className="text-gray-500">Take a quiz to see your results here.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
