
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { DashboardHeader } from "@/components/Dashboard";
import { StudentRegistrationForm, StudentsList } from "@/components/StudentRegistrationForm";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function RegisterStudent() {
  const { isAuthenticated, isStaff, currentUser } = useAuth();
  const navigate = useNavigate();
  const [refreshCounter, setRefreshCounter] = useState(0);
  
  useEffect(() => {
    if (!isAuthenticated || !isStaff) {
      navigate("/login");
    }
  }, [isAuthenticated, isStaff, navigate]);

  if (!currentUser) {
    return null;
  }

  const handleStudentAdded = () => {
    setRefreshCounter(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate("/dashboard")}
            className="flex items-center gap-2 text-gray-600"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Dashboard
          </Button>
        </div>
        
        <DashboardHeader 
          title="Register Student" 
          userName={currentUser.username} 
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <StudentRegistrationForm onStudentAdded={handleStudentAdded} />
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <StudentsList key={refreshCounter} />
          </div>
        </div>
      </div>
    </div>
  );
}
