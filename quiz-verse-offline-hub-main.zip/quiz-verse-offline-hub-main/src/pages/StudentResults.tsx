
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { DashboardHeader, ResultCard } from "@/components/Dashboard";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useData } from "@/contexts/DataContext";
import { QuizAttempt, Student } from "@/types";

export default function StudentResults() {
  const { isAuthenticated, isStudent, currentUser } = useAuth();
  const navigate = useNavigate();
  const { getQuizAttempts } = useData();
  const [results, setResults] = useState<QuizAttempt[]>([]);
  
  useEffect(() => {
    if (!isAuthenticated || !isStudent) {
      navigate("/login");
    }
    
    if (currentUser && isStudent) {
      const studentResults = getQuizAttempts(currentUser.id);
      setResults(studentResults);
    }
  }, [isAuthenticated, isStudent, navigate, currentUser, getQuizAttempts]);

  if (!currentUser) {
    return null;
  }

  const student = currentUser as Student;

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate("/dashboard")}
            className="flex items-center gap-2 text-gray-600"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Dashboard
          </Button>
        </div>
        
        <DashboardHeader 
          title="Your Results" 
          userName={student.name} 
          additionalInfo={`USN: ${student.usn} | Section: ${student.section}`}
        />
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Quiz Attempts</h2>
          
          {results.length === 0 ? (
            <p className="text-gray-500">You haven't taken any quizzes yet.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {results.map((result) => (
                <ResultCard
                  key={result.id}
                  subject={result.subject}
                  score={result.score}
                  totalQuestions={result.totalQuestions}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
