
// User types
export type UserRole = "staff" | "student";

export interface User {
  id: string;
  username: string;
  password: string;
  role: UserRole;
}

export interface Staff extends User {
  role: "staff";
  name: string;
}

export interface Student extends User {
  role: "student";
  name: string;
  usn: string;  // University Seat Number
  section: string;
}

// Subject and Question types
export interface Option {
  id: string;
  text: string;
}

export interface Question {
  id: string;
  text: string;
  subject: string;
  options: Option[];
  correctOptionId: string;
}

// Quiz and Result types
export interface QuizAttempt {
  id: string;
  studentId: string;
  subject: string;
  date: string;
  score: number;
  totalQuestions: number;
}

export interface Answer {
  questionId: string;
  selectedOptionId: string;
}

export interface QuizSession {
  subject: string;
  questions: Question[];
  answers: Answer[];
  currentQuestionIndex: number;
}
