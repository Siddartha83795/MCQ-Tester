
import { createContext, useContext, useState, ReactNode } from "react";
import { Question, Answer, QuizSession } from "@/types";
import { useData } from "./DataContext";

interface QuizContextType {
  currentQuiz: QuizSession | null;
  startQuiz: (subject: string) => boolean;
  nextQuestion: () => boolean;
  previousQuestion: () => boolean;
  submitAnswer: (questionId: string, optionId: string) => void;
  finishQuiz: (studentId: string) => { score: number, totalQuestions: number };
  resetQuiz: () => void;
}

const QuizContext = createContext<QuizContextType | undefined>(undefined);

export function QuizProvider({ children }: { children: ReactNode }) {
  const [currentQuiz, setCurrentQuiz] = useState<QuizSession | null>(null);
  const { getQuestions, addQuizAttempt } = useData();

  const startQuiz = (subject: string): boolean => {
    const questions = getQuestions(subject);
    if (questions.length === 0) return false;

    // Shuffle questions for randomized quiz experience
    const shuffledQuestions = [...questions].sort(() => Math.random() - 0.5);

    setCurrentQuiz({
      subject,
      questions: shuffledQuestions,
      answers: [],
      currentQuestionIndex: 0
    });

    return true;
  };

  const nextQuestion = (): boolean => {
    if (!currentQuiz) return false;
    
    if (currentQuiz.currentQuestionIndex < currentQuiz.questions.length - 1) {
      setCurrentQuiz({
        ...currentQuiz,
        currentQuestionIndex: currentQuiz.currentQuestionIndex + 1
      });
      return true;
    }
    return false;
  };

  const previousQuestion = (): boolean => {
    if (!currentQuiz) return false;
    
    if (currentQuiz.currentQuestionIndex > 0) {
      setCurrentQuiz({
        ...currentQuiz,
        currentQuestionIndex: currentQuiz.currentQuestionIndex - 1
      });
      return true;
    }
    return false;
  };

  const submitAnswer = (questionId: string, optionId: string) => {
    if (!currentQuiz) return;
    
    const existingAnswerIndex = currentQuiz.answers.findIndex(
      a => a.questionId === questionId
    );
    
    let newAnswers;
    if (existingAnswerIndex >= 0) {
      newAnswers = [...currentQuiz.answers];
      newAnswers[existingAnswerIndex] = { questionId, selectedOptionId: optionId };
    } else {
      newAnswers = [...currentQuiz.answers, { questionId, selectedOptionId: optionId }];
    }
    
    setCurrentQuiz({
      ...currentQuiz,
      answers: newAnswers
    });
  };

  const finishQuiz = (studentId: string): { score: number, totalQuestions: number } => {
    if (!currentQuiz) return { score: 0, totalQuestions: 0 };
    
    const { questions, answers, subject } = currentQuiz;
    let score = 0;
    
    questions.forEach(question => {
      const answer = answers.find(a => a.questionId === question.id);
      if (answer && answer.selectedOptionId === question.correctOptionId) {
        score++;
      }
    });
    
    const totalQuestions = questions.length;
    
    // Save quiz attempt
    addQuizAttempt({
      studentId,
      subject,
      date: new Date().toISOString(),
      score,
      totalQuestions
    });
    
    return { score, totalQuestions };
  };

  const resetQuiz = () => {
    setCurrentQuiz(null);
  };

  return (
    <QuizContext.Provider
      value={{
        currentQuiz,
        startQuiz,
        nextQuestion,
        previousQuestion,
        submitAnswer,
        finishQuiz,
        resetQuiz
      }}
    >
      {children}
    </QuizContext.Provider>
  );
}

export const useQuiz = () => {
  const context = useContext(QuizContext);
  if (context === undefined) {
    throw new Error("useQuiz must be used within a QuizProvider");
  }
  return context;
};
