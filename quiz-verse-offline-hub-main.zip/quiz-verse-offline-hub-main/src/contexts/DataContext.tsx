
import { createContext, useContext, ReactNode } from "react";
import { Student, Question, QuizAttempt } from "@/types";

interface DataContextType {
  // Student management
  getStudents: () => Student[];
  getStudent: (id: string) => Student | undefined;
  addStudent: (student: Omit<Student, "id" | "role">) => Student;
  updateStudent: (student: Student) => boolean;
  deleteStudent: (id: string) => boolean;
  
  // Question management
  getQuestions: (subject?: string) => Question[];
  getQuestion: (id: string) => Question | undefined;
  addQuestion: (question: Omit<Question, "id">) => Question;
  updateQuestion: (question: Question) => boolean;
  deleteQuestion: (id: string) => boolean;
  getSubjects: () => string[];
  
  // Quiz attempts
  getQuizAttempts: (studentId?: string, subject?: string) => QuizAttempt[];
  addQuizAttempt: (attempt: Omit<QuizAttempt, "id">) => QuizAttempt;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  // Student operations
  const getStudents = (): Student[] => {
    const usersJson = localStorage.getItem("users") || "[]";
    const users = JSON.parse(usersJson);
    return users.filter((user: any) => user.role === "student");
  };

  const getStudent = (id: string): Student | undefined => {
    return getStudents().find(student => student.id === id);
  };

  const addStudent = (studentData: Omit<Student, "id" | "role">): Student => {
    const usersJson = localStorage.getItem("users") || "[]";
    const users = JSON.parse(usersJson);
    
    const newStudent: Student = {
      id: Date.now().toString(),
      role: "student",
      ...studentData
    };
    
    users.push(newStudent);
    localStorage.setItem("users", JSON.stringify(users));
    return newStudent;
  };

  const updateStudent = (updatedStudent: Student): boolean => {
    const usersJson = localStorage.getItem("users") || "[]";
    const users = JSON.parse(usersJson);
    
    const index = users.findIndex((user: any) => user.id === updatedStudent.id);
    if (index === -1) return false;
    
    users[index] = updatedStudent;
    localStorage.setItem("users", JSON.stringify(users));
    return true;
  };

  const deleteStudent = (id: string): boolean => {
    const usersJson = localStorage.getItem("users") || "[]";
    const users = JSON.parse(usersJson);
    
    const newUsers = users.filter((user: any) => user.id !== id);
    if (newUsers.length === users.length) return false;
    
    localStorage.setItem("users", JSON.stringify(newUsers));
    return true;
  };

  // Question operations
  const getQuestions = (subject?: string): Question[] => {
    const questionsJson = localStorage.getItem("questions") || "[]";
    const questions: Question[] = JSON.parse(questionsJson);
    
    if (subject) {
      return questions.filter(q => q.subject === subject);
    }
    return questions;
  };

  const getQuestion = (id: string): Question | undefined => {
    const questions = getQuestions();
    return questions.find(q => q.id === id);
  };

  const addQuestion = (questionData: Omit<Question, "id">): Question => {
    const questionsJson = localStorage.getItem("questions") || "[]";
    const questions: Question[] = JSON.parse(questionsJson);
    
    const newQuestion: Question = {
      id: Date.now().toString(),
      ...questionData
    };
    
    questions.push(newQuestion);
    localStorage.setItem("questions", JSON.stringify(questions));
    return newQuestion;
  };

  const updateQuestion = (updatedQuestion: Question): boolean => {
    const questionsJson = localStorage.getItem("questions") || "[]";
    const questions: Question[] = JSON.parse(questionsJson);
    
    const index = questions.findIndex(q => q.id === updatedQuestion.id);
    if (index === -1) return false;
    
    questions[index] = updatedQuestion;
    localStorage.setItem("questions", JSON.stringify(questions));
    return true;
  };

  const deleteQuestion = (id: string): boolean => {
    const questionsJson = localStorage.getItem("questions") || "[]";
    const questions: Question[] = JSON.parse(questionsJson);
    
    const newQuestions = questions.filter(q => q.id !== id);
    if (newQuestions.length === questions.length) return false;
    
    localStorage.setItem("questions", JSON.stringify(newQuestions));
    return true;
  };

  const getSubjects = (): string[] => {
    const questions = getQuestions();
    const subjectsSet = new Set<string>();
    
    questions.forEach(q => {
      if (q.subject) subjectsSet.add(q.subject);
    });
    
    return Array.from(subjectsSet);
  };

  // Quiz attempt operations
  const getQuizAttempts = (studentId?: string, subject?: string): QuizAttempt[] => {
    const attemptsJson = localStorage.getItem("quizAttempts") || "[]";
    const attempts: QuizAttempt[] = JSON.parse(attemptsJson);
    
    return attempts.filter(attempt => {
      const matchesStudent = !studentId || attempt.studentId === studentId;
      const matchesSubject = !subject || attempt.subject === subject;
      return matchesStudent && matchesSubject;
    });
  };

  const addQuizAttempt = (attemptData: Omit<QuizAttempt, "id">): QuizAttempt => {
    const attemptsJson = localStorage.getItem("quizAttempts") || "[]";
    const attempts: QuizAttempt[] = JSON.parse(attemptsJson);
    
    const newAttempt: QuizAttempt = {
      id: Date.now().toString(),
      ...attemptData
    };
    
    attempts.push(newAttempt);
    localStorage.setItem("quizAttempts", JSON.stringify(attempts));
    return newAttempt;
  };

  return (
    <DataContext.Provider
      value={{
        getStudents,
        getStudent,
        addStudent,
        updateStudent,
        deleteStudent,
        getQuestions,
        getQuestion,
        addQuestion,
        updateQuestion,
        deleteQuestion,
        getSubjects,
        getQuizAttempts,
        addQuizAttempt
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
};
