
import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { User, Staff, Student } from "@/types";

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  isStaff: boolean;
  isStudent: boolean;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  registerStaff: (username: string, password: string, name: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Load user from localStorage on initial render
  useEffect(() => {
    const storedUser = localStorage.getItem("currentUser");
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
      setIsAuthenticated(true);
    }
  }, []);

  const login = (username: string, password: string): boolean => {
    // Get users from localStorage
    const usersJson = localStorage.getItem("users") || "[]";
    const users: User[] = JSON.parse(usersJson);

    // Find the user
    const user = users.find(u => u.username === username && u.password === password);
    
    if (user) {
      setCurrentUser(user);
      setIsAuthenticated(true);
      localStorage.setItem("currentUser", JSON.stringify(user));
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem("currentUser");
  };

  const registerStaff = (username: string, password: string, name: string): boolean => {
    // Get users from localStorage
    const usersJson = localStorage.getItem("users") || "[]";
    const users: User[] = JSON.parse(usersJson);

    // Check if username already exists
    if (users.some(u => u.username === username)) {
      return false;
    }

    // Create new staff
    const newStaff: Staff = {
      id: Date.now().toString(),
      username,
      password,
      name,
      role: "staff"
    };

    // Add staff to users and save to localStorage
    users.push(newStaff);
    localStorage.setItem("users", JSON.stringify(users));
    return true;
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated,
        isStaff: currentUser?.role === "staff",
        isStudent: currentUser?.role === "student",
        login,
        logout,
        registerStaff,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
