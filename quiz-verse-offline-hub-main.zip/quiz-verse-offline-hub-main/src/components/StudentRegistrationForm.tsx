
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useData } from "@/contexts/DataContext";
import { Student } from "@/types";
import { X } from "lucide-react";

interface StudentRegistrationFormProps {
  onStudentAdded?: () => void;
}

export function StudentRegistrationForm({ onStudentAdded }: StudentRegistrationFormProps) {
  const [usn, setUsn] = useState("");
  const [name, setName] = useState("");
  const [section, setSection] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  
  const { addStudent, getStudents } = useData();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!usn || !name || !section || !password) {
      setError("All fields are required");
      return;
    }
    
    // Check if USN already exists
    const students = getStudents();
    if (students.some((student: Student) => student.usn === usn)) {
      setError("Student with this USN already exists");
      return;
    }
    
    // Add student
    addStudent({
      username: usn, // Use USN as username
      password,
      name,
      usn,
      section
    });
    
    // Reset form
    setUsn("");
    setName("");
    setSection("");
    setPassword("");
    
    // Notify parent
    if (onStudentAdded) {
      onStudentAdded();
    }
  };

  return (
    <div>
      <h3 className="text-lg font-medium mb-4">Add New Student</h3>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="usn">USN (University Seat Number)</Label>
          <Input
            id="usn"
            placeholder="e.g., 1SI18CS001"
            value={usn}
            onChange={(e) => setUsn(e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="student-name">Name</Label>
          <Input
            id="student-name"
            placeholder="Full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="section">Section</Label>
          <Input
            id="section"
            placeholder="e.g., A, B, C"
            value={section}
            onChange={(e) => setSection(e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="student-password">Password</Label>
          <Input
            id="student-password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        
        {error && <p className="text-sm text-red-500">{error}</p>}
        
        <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700">
          Register Student
        </Button>
      </form>
    </div>
  );
}

export function StudentsList() {
  const { getStudents, deleteStudent } = useData();
  const [students, setStudents] = useState<Student[]>(getStudents());
  
  const handleDelete = (id: string) => {
    deleteStudent(id);
    setStudents(getStudents());
  };
  
  const handleRefresh = () => {
    setStudents(getStudents());
  };

  return (
    <div>
      <h3 className="text-lg font-medium mb-4">Registered Students</h3>
      
      <div className="space-y-4">
        {students.length === 0 ? (
          <p className="text-gray-500">No students registered yet</p>
        ) : (
          students.map((student) => (
            <div key={student.id} className="p-4 border rounded-md bg-gray-50 flex justify-between items-center">
              <div>
                <h4 className="font-medium">{student.name}</h4>
                <p className="text-sm text-gray-600">USN: {student.usn}</p>
                <p className="text-sm text-gray-600">Section: {student.section}</p>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => handleDelete(student.id)}
                className="text-red-500 hover:text-red-700 hover:bg-red-50"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
