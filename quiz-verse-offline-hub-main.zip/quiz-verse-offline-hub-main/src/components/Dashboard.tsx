
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { LogOut } from "lucide-react";
import { Link } from "react-router-dom";

interface DashboardHeaderProps {
  title: string;
  userName: string;
  additionalInfo?: string;
}

export function DashboardHeader({ title, userName, additionalInfo }: DashboardHeaderProps) {
  const { logout } = useAuth();

  return (
    <div className="flex justify-between items-center p-6 bg-white rounded-lg shadow mb-6">
      <div>
        <h1 className="text-2xl font-bold">{title}</h1>
        <p className="text-gray-600">Welcome, {userName}</p>
        {additionalInfo && (
          <p className="text-sm text-gray-500">{additionalInfo}</p>
        )}
      </div>
      <Button 
        onClick={logout} 
        variant="outline" 
        className="flex items-center gap-2"
      >
        <LogOut className="h-4 w-4" /> Logout
      </Button>
    </div>
  );
}

interface DashboardCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  to: string;
}

export function DashboardCard({ title, description, icon, to }: DashboardCardProps) {
  return (
    <Link to={to} className="block">
      <div className="p-6 bg-white rounded-lg shadow-sm hover:shadow transition-shadow flex flex-col h-full">
        <div className="mb-4 text-indigo-600">
          {icon}
        </div>
        <h2 className="text-xl font-semibold mb-2">{title}</h2>
        <p className="text-gray-600 text-sm">{description}</p>
      </div>
    </Link>
  );
}

interface ResultCardProps {
  subject: string;
  score: number;
  totalQuestions: number;
}

export function ResultCard({ subject, score, totalQuestions }: ResultCardProps) {
  const percentage = Math.round((score / totalQuestions) * 100);
  
  let colorClass = "text-red-600";
  if (percentage >= 90) {
    colorClass = "text-green-600";
  } else if (percentage >= 70) {
    colorClass = "text-blue-600";
  } else if (percentage >= 50) {
    colorClass = "text-amber-600";
  }

  return (
    <div className="p-4 bg-white rounded-lg shadow-sm border-l-4 border-indigo-500">
      <h3 className="font-medium mb-1">{subject}</h3>
      <p className={`font-bold ${colorClass}`}>
        Score: {score} / {totalQuestions}
      </p>
    </div>
  );
}
