
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { User } from "lucide-react";

export function LoginForm() {
  const [activeTab, setActiveTab] = useState<"staff" | "student">("staff");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!username || !password) {
      setError("Please enter both username and password");
      return;
    }
    
    const success = login(username, password);
    if (success) {
      navigate("/dashboard");
    } else {
      setError("Invalid username or password");
    }
  };

  return (
    <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-lg">
      <Tabs 
        defaultValue="staff" 
        value={activeTab} 
        onValueChange={(value) => setActiveTab(value as "staff" | "student")}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="staff" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Staff Login
          </TabsTrigger>
          <TabsTrigger value="student" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Student Login
          </TabsTrigger>
        </TabsList>
        
        <h2 className="text-2xl font-bold text-center mb-6">MCQ Tester</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <TabsContent value="staff">
            <div className="space-y-2">
              <Label htmlFor="staff-username">Username</Label>
              <Input
                id="staff-username"
                placeholder="Enter username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
          </TabsContent>
          
          <TabsContent value="student">
            <div className="space-y-2">
              <Label htmlFor="student-usn">USN</Label>
              <Input
                id="student-usn"
                placeholder="Enter USN (e.g., ENG23CT0015)"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
          </TabsContent>
          
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          
          {error && <p className="text-sm text-red-500">{error}</p>}
          
          <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700">
            Login
          </Button>
        </form>
      </Tabs>
      
      <div className="mt-4 text-center">
        <a href="/register-staff" className="text-sm text-indigo-600 hover:underline">
          Register New Staff
        </a>
      </div>
    </div>
  );
}
