
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useData } from "@/contexts/DataContext";
import { QuizAttempt, Student } from "@/types";
import { Download } from "lucide-react";

export function ResultsViewer() {
  const { getQuizAttempts, getSubjects, getStudents, getStudent } = useData();
  const [selectedSubject, setSelectedSubject] = useState<string>("all");
  const [usnFilter, setUsnFilter] = useState<string>("");
  const [nameFilter, setNameFilter] = useState<string>("");
  const [subjects, setSubjects] = useState<string[]>([]);
  const [results, setResults] = useState<(QuizAttempt & { studentName: string })[]>([]);

  useEffect(() => {
    setSubjects(getSubjects());
    fetchResults();
  }, [selectedSubject, usnFilter, nameFilter]);

  const fetchResults = () => {
    const attempts = getQuizAttempts();
    const students = getStudents();
    
    const studentMap = new Map<string, Student>();
    students.forEach(student => {
      studentMap.set(student.id, student);
    });
    
    const enrichedAttempts = attempts
      .filter(attempt => {
        const student = studentMap.get(attempt.studentId);
        if (!student) return false;
        
        const matchesSubject = selectedSubject === "all" || attempt.subject === selectedSubject;
        const matchesUsn = !usnFilter || student.usn.toLowerCase().includes(usnFilter.toLowerCase());
        const matchesName = !nameFilter || student.name.toLowerCase().includes(nameFilter.toLowerCase());
        
        return matchesSubject && matchesUsn && matchesName;
      })
      .map(attempt => {
        const student = studentMap.get(attempt.studentId);
        return {
          ...attempt,
          studentName: student ? student.name : "Unknown Student"
        };
      });
    
    setResults(enrichedAttempts);
  };

  const exportToCSV = () => {
    const headers = ["USN", "NAME", "SUBJECT", "SCORE", "TOTAL", "DATE"];
    
    const csvRows = results.map(result => {
      const student = getStudent(result.studentId);
      return [
        student?.usn || "Unknown",
        result.studentName,
        result.subject,
        result.score.toString(),
        result.totalQuestions.toString(),
        new Date(result.date).toLocaleDateString()
      ];
    });
    
    const csvContent = [
      headers.join(','),
      ...csvRows.map(row => row.join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'quiz_results.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Result Viewer</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium mb-1">Subject</label>
          <Select onValueChange={setSelectedSubject} value={selectedSubject}>
            <SelectTrigger>
              <SelectValue placeholder="All Subjects" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Subjects</SelectItem>
              {subjects.map((subject) => (
                <SelectItem key={subject} value={subject}>
                  {subject}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">USN</label>
          <Input
            placeholder="Filter by USN"
            value={usnFilter}
            onChange={(e) => setUsnFilter(e.target.value)}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">Name</label>
          <Input
            placeholder="Filter by name"
            value={nameFilter}
            onChange={(e) => setNameFilter(e.target.value)}
          />
        </div>
      </div>
      
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">Student Results</h3>
        <Button 
          onClick={exportToCSV} 
          variant="outline" 
          className="flex items-center gap-2 text-green-600 border-green-600 hover:bg-green-50"
        >
          <Download className="h-4 w-4" />
          Export to CSV
        </Button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border">
          <thead>
            <tr className="bg-gray-100">
              <th className="py-2 px-4 border text-left">USN</th>
              <th className="py-2 px-4 border text-left">NAME</th>
              <th className="py-2 px-4 border text-left">SUBJECT</th>
              <th className="py-2 px-4 border text-center">SCORE</th>
            </tr>
          </thead>
          <tbody>
            {results.length === 0 ? (
              <tr>
                <td colSpan={4} className="py-4 text-center text-gray-500">
                  No results found
                </td>
              </tr>
            ) : (
              results.map((result) => {
                const student = getStudent(result.studentId);
                return (
                  <tr key={result.id}>
                    <td className="py-2 px-4 border">{student?.usn || "Unknown"}</td>
                    <td className="py-2 px-4 border">{result.studentName}</td>
                    <td className="py-2 px-4 border">{result.subject}</td>
                    <td className="py-2 px-4 border text-center">
                      <span className="font-medium text-amber-600">{result.score}</span>
                      <span className="text-gray-500 ml-1">/ {result.totalQuestions}</span>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
