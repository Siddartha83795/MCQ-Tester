
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useData } from "@/contexts/DataContext";
import { Question, Option } from "@/types";
import { X, Plus } from "lucide-react";

export function QuestionManagementForm() {
  const { addQuestion, getSubjects } = useData();
  const [subjects, setSubjects] = useState<string[]>([]);
  const [newSubject, setNewSubject] = useState("");
  const [showNewSubjectField, setShowNewSubjectField] = useState(false);
  
  const [subject, setSubject] = useState("");
  const [questionText, setQuestionText] = useState("");
  const [options, setOptions] = useState<Omit<Option, "id">[]>([
    { text: "" }, { text: "" }, { text: "" }, { text: "" }
  ]);
  const [correctOptionIndex, setCorrectOptionIndex] = useState<number>(0);
  const [error, setError] = useState("");

  // Load subjects
  useEffect(() => {
    setSubjects(getSubjects());
  }, [getSubjects]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (showNewSubjectField && newSubject.trim()) {
      setSubject(newSubject.trim());
    }
    
    if (!subject) {
      setError("Please select or enter a subject");
      return;
    }
    
    if (!questionText.trim()) {
      setError("Question text is required");
      return;
    }
    
    // Check if all options have text and at least two options are provided
    const validOptions = options.filter(opt => opt.text.trim());
    if (validOptions.length < 2) {
      setError("At least two options are required");
      return;
    }
    
    // Create option IDs and question
    const optionsWithIds: Option[] = validOptions.map((opt, index) => ({
      id: `opt-${Date.now()}-${index}`,
      text: opt.text.trim()
    }));
    
    const correctOptionId = optionsWithIds[correctOptionIndex]?.id || optionsWithIds[0].id;
    
    addQuestion({
      text: questionText.trim(),
      subject,
      options: optionsWithIds,
      correctOptionId
    });
    
    // Reset form
    setQuestionText("");
    setOptions([{ text: "" }, { text: "" }, { text: "" }, { text: "" }]);
    setCorrectOptionIndex(0);
    
    // Add new subject to the list if necessary
    if (showNewSubjectField && newSubject.trim() && !subjects.includes(newSubject.trim())) {
      setSubjects([...subjects, newSubject.trim()]);
      setNewSubject("");
      setShowNewSubjectField(false);
    }
  };

  const handleOptionChange = (index: number, text: string) => {
    const newOptions = [...options];
    newOptions[index] = { text };
    setOptions(newOptions);
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <h3 className="text-xl font-medium">Add New Question</h3>
        <Button 
          type="button" 
          size="sm" 
          variant="outline"
          onClick={() => setShowNewSubjectField(!showNewSubjectField)}
        >
          <Plus className="h-4 w-4 mr-1" /> 
          {showNewSubjectField ? "Select Subject" : "Add New Subject"}
        </Button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="subject">Subject</Label>
          {showNewSubjectField ? (
            <Input
              id="new-subject"
              placeholder="Enter new subject name"
              value={newSubject}
              onChange={(e) => setNewSubject(e.target.value)}
            />
          ) : (
            <Select onValueChange={setSubject} value={subject}>
              <SelectTrigger>
                <SelectValue placeholder="Select Subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((subj) => (
                  <SelectItem key={subj} value={subj}>
                    {subj}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="question-text">Question</Label>
          <Textarea
            id="question-text"
            placeholder="Enter your question"
            value={questionText}
            onChange={(e) => setQuestionText(e.target.value)}
            rows={3}
          />
        </div>
        
        <div className="space-y-4">
          <Label>Options</Label>
          {options.map((option, index) => (
            <div key={index} className="flex items-center gap-3">
              <div className="flex-grow">
                <Input
                  placeholder={`Option ${index + 1}`}
                  value={option.text}
                  onChange={(e) => handleOptionChange(index, e.target.value)}
                />
              </div>
              <div className="flex items-center">
                <input
                  type="radio"
                  name="correct-option"
                  checked={correctOptionIndex === index}
                  onChange={() => setCorrectOptionIndex(index)}
                  className="mr-2"
                />
                <Label className="text-sm">Correct</Label>
              </div>
            </div>
          ))}
        </div>
        
        {error && <p className="text-sm text-red-500">{error}</p>}
        
        <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
          Add Question
        </Button>
      </form>
    </div>
  );
}

export function QuestionsList() {
  const { getQuestions, deleteQuestion, getSubjects } = useData();
  const [selectedSubject, setSelectedSubject] = useState<string>("all");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [subjects, setSubjects] = useState<string[]>([]);

  useEffect(() => {
    setSubjects(getSubjects());
    updateQuestions();
  }, [selectedSubject, getQuestions, getSubjects]);

  const updateQuestions = () => {
    if (selectedSubject === "all") {
      setQuestions(getQuestions());
    } else {
      setQuestions(getQuestions(selectedSubject));
    }
  };

  const handleDelete = (id: string) => {
    deleteQuestion(id);
    updateQuestions();
  };

  return (
    <div className="mt-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-medium">All Questions</h3>
        <Select onValueChange={setSelectedSubject} value={selectedSubject}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="All Subjects" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Subjects</SelectItem>
            {subjects.map((subject) => (
              <SelectItem key={subject} value={subject}>
                {subject}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-4">
        {questions.length === 0 ? (
          <p className="text-gray-500">No questions found</p>
        ) : (
          questions.map((question) => (
            <div key={question.id} className="p-4 border rounded-md bg-gray-50">
              <div className="flex justify-between items-start">
                <div>
                  <div className="inline-block px-2 py-1 text-xs bg-indigo-100 text-indigo-800 rounded mb-2">
                    {question.subject}
                  </div>
                  <p className="font-medium mb-2">{question.text}</p>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => handleDelete(question.id)}
                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
              
              <div className="mt-2 grid grid-cols-2 gap-2">
                {question.options.map((option) => (
                  <div 
                    key={option.id} 
                    className={`text-sm p-2 rounded ${
                      option.id === question.correctOptionId 
                        ? "bg-green-100 border border-green-300" 
                        : "bg-gray-100"
                    }`}
                  >
                    {option.text}
                    {option.id === question.correctOptionId && (
                      <span className="ml-2 text-green-600 text-xs">(Correct)</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
