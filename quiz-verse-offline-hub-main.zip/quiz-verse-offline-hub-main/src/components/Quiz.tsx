
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useQuiz } from "@/contexts/QuizContext";
import { Question as QuestionType } from "@/types";
import { ArrowLeft, ArrowRight, CheckCircle } from "lucide-react";

interface QuizCardProps {
  subject: string;
  description: string;
  onStartQuiz: () => void;
}

export function QuizCard({ subject, description, onStartQuiz }: QuizCardProps) {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <CardTitle>{subject}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-sm text-gray-500">
          Test your knowledge on {subject} topics with multiple choice questions.
        </p>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={onStartQuiz} 
          className="w-full bg-indigo-600 hover:bg-indigo-700"
        >
          Start Quiz
        </Button>
      </CardFooter>
    </Card>
  );
}

interface QuizQuestionProps {
  question: QuestionType;
  selectedAnswer?: string;
  onAnswerSelected: (questionId: string, optionId: string) => void;
  onNext: () => void;
  onPrevious: () => void;
  onFinish: () => void;
  isFirst: boolean;
  isLast: boolean;
  currentIndex: number;
  totalQuestions: number;
}

export function QuizQuestion({
  question,
  selectedAnswer,
  onAnswerSelected,
  onNext,
  onPrevious,
  onFinish,
  isFirst,
  isLast,
  currentIndex,
  totalQuestions
}: QuizQuestionProps) {
  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="mb-4 flex justify-between items-center">
        <span className="text-sm text-gray-500">
          Question {currentIndex + 1} of {totalQuestions}
        </span>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-xl">
            {question.text}
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <RadioGroup
            value={selectedAnswer}
            onValueChange={(value) => onAnswerSelected(question.id, value)}
            className="space-y-3"
          >
            {question.options.map((option) => (
              <div key={option.id} className="flex items-center">
                <RadioGroupItem value={option.id} id={option.id} />
                <Label htmlFor={option.id} className="ml-2 flex-grow">
                  {option.text}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
        
        <CardFooter className="flex justify-between">
          <Button
            onClick={onPrevious}
            disabled={isFirst}
            variant="outline"
            className="flex items-center gap-1"
          >
            <ArrowLeft className="h-4 w-4" /> Previous
          </Button>
          
          {isLast ? (
            <Button
              onClick={onFinish}
              className="bg-green-600 hover:bg-green-700 flex items-center gap-1"
            >
              Finish Quiz <CheckCircle className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              onClick={onNext}
              className="bg-indigo-600 hover:bg-indigo-700 flex items-center gap-1"
            >
              Next <ArrowRight className="h-4 w-4" />
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}

interface QuizResultProps {
  subject: string;
  score: number;
  totalQuestions: number;
  onBackToDashboard: () => void;
}

export function QuizResult({
  subject,
  score,
  totalQuestions,
  onBackToDashboard
}: QuizResultProps) {
  const percentage = Math.round((score / totalQuestions) * 100);
  
  let resultMessage = "Try Again!";
  let resultClass = "text-red-600";
  
  if (percentage >= 90) {
    resultMessage = "Excellent!";
    resultClass = "text-green-600";
  } else if (percentage >= 70) {
    resultMessage = "Great Job!";
    resultClass = "text-blue-600";
  } else if (percentage >= 50) {
    resultMessage = "Good Effort!";
    resultClass = "text-amber-600";
  }

  return (
    <div className="w-full max-w-md mx-auto">
      <Card className="text-center">
        <CardHeader>
          <CardTitle>Quiz Result</CardTitle>
          <CardDescription>{subject}</CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="text-3xl font-bold">
            <span className={resultClass}>{resultMessage}</span>
          </div>
          
          <div className="text-2xl">
            <span className="font-bold">{score}</span>
            <span className="text-gray-500"> / {totalQuestions}</span>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-4">
            <div
              className={`h-4 rounded-full ${
                percentage >= 70 
                  ? "bg-green-600" 
                  : percentage >= 50 
                    ? "bg-amber-500" 
                    : "bg-red-500"
              }`}
              style={{ width: `${percentage}%` }}
            ></div>
          </div>
          
          <p className="text-gray-600">
            You answered {score} out of {totalQuestions} questions correctly.
          </p>
        </CardContent>
        
        <CardFooter className="justify-center">
          <Button 
            onClick={onBackToDashboard}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            Back to Dashboard
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

export function QuizContainer({
  subject,
  studentId,
  onQuizComplete
}: {
  subject: string;
  studentId: string;
  onQuizComplete: () => void;
}) {
  const { 
    startQuiz, 
    currentQuiz, 
    nextQuestion, 
    previousQuestion, 
    submitAnswer, 
    finishQuiz, 
    resetQuiz 
  } = useQuiz();
  
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [quizResult, setQuizResult] = useState<{ score: number; totalQuestions: number }>({
    score: 0,
    totalQuestions: 0
  });

  useEffect(() => {
    startQuiz(subject);
    
    return () => {
      resetQuiz();
    };
  }, [subject]);

  if (!currentQuiz) {
    return <div>Loading quiz...</div>;
  }

  if (quizCompleted) {
    return (
      <QuizResult
        subject={subject}
        score={quizResult.score}
        totalQuestions={quizResult.totalQuestions}
        onBackToDashboard={onQuizComplete}
      />
    );
  }

  const currentQuestion = currentQuiz.questions[currentQuiz.currentQuestionIndex];
  const selectedAnswer = currentQuiz.answers.find(
    a => a.questionId === currentQuestion.id
  )?.selectedOptionId;
  
  const handleFinishQuiz = () => {
    const result = finishQuiz(studentId);
    setQuizResult(result);
    setQuizCompleted(true);
  };

  return (
    <QuizQuestion
      question={currentQuestion}
      selectedAnswer={selectedAnswer}
      onAnswerSelected={submitAnswer}
      onNext={nextQuestion}
      onPrevious={previousQuestion}
      onFinish={handleFinishQuiz}
      isFirst={currentQuiz.currentQuestionIndex === 0}
      isLast={currentQuiz.currentQuestionIndex === currentQuiz.questions.length - 1}
      currentIndex={currentQuiz.currentQuestionIndex}
      totalQuestions={currentQuiz.questions.length}
    />
  );
}
